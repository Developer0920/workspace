package mini;
//선택된 파일을 로컬에서 찾아서 실행하기
public class Play {
	
	//선택된 번호
	private play_number;
	public void play_file(int number) {
		//선택된 mp3파일 로컬에서 불러와서 재생
	}
}
