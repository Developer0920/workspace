package mini;

public class Main {

	public static void main(String[] args) {
		
		
		//첫화면
			//1. log클래스 init()호출
			//2. 유저객체 생성
			//3. 그결과에 따라서 회원가입 or 로그인 결정
			//4. 유저 객체 생성
			//5. 로그인 성공
			//6. 회원의 리스트유무 체크해서 있으면 보여주고 없으면 만들기
			//7. 플레이 리스트에서 선택한 파일 실행
			//8. 다시플레이 리스트 or 종료

	
	}
}
