package mini;
//로그인 관련을 처리 담당하는 클래스
//하나만 존재하면 되기 때문에 왠만하면 Singleton 사용하면 좋을듯한
public class Log {

	
	//기존회원 유무 판별함수
	public boolean init() {
		
		//기존회원 유무인지를 판별해서 리턴
	}
	
	//회원가입
	public boolean newjoin() {
		//새로 가입
		//DB에 유저정보 저장
	}
	
	//기존 유저 로그인
	public boolean login() {
		//DB연걸해서 로그인
	}
	
}
